/*
 * File: 4-puts.c
 * Auth: Brennan D Baraban <375@holbertonschool.com>
 */

#include <stdio.h>

/**
 * main - Prints "Programming is like building a multilingual
 *                puzzle, followed by a new line.
 *
 * Return: Always 0.
 */
int main(void)
{
	puts("\"Programming is like building a multilingual puzzle");

	return (0);
}
